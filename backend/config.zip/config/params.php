<?php
return [
    'adminEmail' => 'saqinrehan587@gmail.com',
];
